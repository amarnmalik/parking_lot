package com.carparking.system;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class CarParkingManager {
	 
	public static void main(String[] args) {

		ParkingLot parkingLot = new ParkingLot();
		String[] vehicleTypes = { "Car" };
		try {
			FileInputStream fis = new FileInputStream(args[0]);
			Scanner sc = new Scanner(fis);
			boolean parkingSlotCreated = true;
			String[] commands;
			while (sc.hasNextLine()) {
				commands = sc.nextLine().split(" ");

				if (Commands.create_parking_lot.toString().equals(commands[0])) {
					try {
						parkingLot.createParkingLot(Integer.parseInt(commands[1]));
					} catch (ArrayIndexOutOfBoundsException ex) {
						parkingSlotCreated = false;
						System.out.println("Provide slots");
					}
				} else if (Commands.park.toString().equals(commands[0]) && parkingSlotCreated) {
					try {
						Vehicle v = new Vehicle(commands[1], vehicleTypes[0], 0);
						parkingLot.parkVehicle(v);
					} catch (RuntimeException ex ) {
						System.out.println(ex.getMessage());
					}
				} else if (Commands.leave.toString().equals(commands[0]) && parkingSlotCreated) {
					Vehicle v = new Vehicle(commands[1], vehicleTypes[0], Integer.parseInt(commands[2]));
					try {
						parkingLot.unparkVehicle(v);	
					} catch (RuntimeException ex ) {
						System.out.println(ex.getMessage());
					}
				} else if (Commands.status.toString().equals(commands[0]) && parkingSlotCreated) {
					parkingLot.parkingStatus();
				}

			}
			sc.close();

		} catch (IOException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}