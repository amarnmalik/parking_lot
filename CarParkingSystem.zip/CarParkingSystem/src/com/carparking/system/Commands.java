package com.carparking.system;

public enum Commands {
	create_parking_lot, park, leave, status;
}
