package com.carparking.system;

public class CostCalculator {
	private static final int initialParkingCharge = 10;
	private static final int initialParkingDuration = 2;
	private static final int additionalChargePerHour = 10;
	
	public int getCost(int parkingDuration) {
		int totalParkingCost = initialParkingCharge;
		if(parkingDuration > initialParkingDuration) {
			totalParkingCost += (parkingDuration - initialParkingDuration) * additionalChargePerHour;
		}
		return totalParkingCost;
	}
}