package com.carparking.system;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class ParkingLot {
    private final Collection<Slot> freeParkingSlots = new TreeSet<>();
    private final Collection<Slot> allParkingSlots = new HashSet<>();
    private final Map<Slot, Vehicle> parkingVehicles = new TreeMap<>();
    private List<Ticket> tickets = new ArrayList<>();
    
    public void createParkingLot(int numberOfSlots) {
        for (int i = 1; i <= numberOfSlots; i++) {
        	allParkingSlots.add(new Slot(i));
        }
        // all slots initially free
        freeParkingSlots.addAll(allParkingSlots);
        System.out.println("Created parking lot with "+numberOfSlots+" slots");
    }

    public void parkVehicle(Vehicle vehicle) {
	        Slot targetSlot = freeParkingSlots.stream().findFirst()
	                .orElseThrow(() -> new RuntimeException("Sorry, parking lot is full."));
	        freeParkingSlots.remove(targetSlot);
	        parkingVehicles.put(targetSlot, vehicle);
	        tickets.add(new Ticket(vehicle, targetSlot));
	        System.out.println("Allocated slot number: "+targetSlot);
    }

    public void unparkVehicle(Vehicle vehicle) {
    	Ticket ticket = tickets.stream().filter(e -> e.getVehicle().getNumberPlate().equals(vehicle.getNumberPlate())).
    			findFirst().orElseThrow(() -> new RuntimeException("Registration number "+vehicle.getNumberPlate()+" not found.")); 
        parkingVehicles.remove(ticket.getSlot());
        freeParkingSlots.add(ticket.getSlot()); // set keeps uniqueness
        System.out.println("Registration number "+vehicle.getNumberPlate()+" with Slot Number "+ticket.getSlot()+
        		" is free with Charge "+ticket.calculateCost(vehicle.getParkingDuration()));
    }

    public void parkingStatus() {
    	if(parkingVehicles.isEmpty()) System.out.println("Parking is emplty.");
    	else {
	    	System.out.println("Slot No.	Registration No.");
	    	
	    	parkingVehicles.forEach((k, v) -> {
	    		System.out.println(k+"	\t"+v.getNumberPlate());
	    	});
    	}
    }
}