package com.carparking.system;

public class Slot implements Comparable<Slot> {

	private final int id;

	public Slot(int id) { 
		this.id = id; 
	}
	 
	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return String.valueOf(id);
	}

	@Override
	public int compareTo(Slot s) {
		return this.id - s.id;
	}

}