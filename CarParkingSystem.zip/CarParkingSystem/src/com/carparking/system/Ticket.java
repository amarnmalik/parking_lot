package com.carparking.system;

import java.util.Random;

public class Ticket {

    private long ticketId;
    private final Vehicle vehicle;
    Random random = new Random();
    private final Slot slot;
    private CostCalculator calculator;

    public Ticket(Vehicle vehicle, Slot slot) {
        super();
        ticketId = random.nextInt();
        this.vehicle = vehicle;
        this.slot = slot;
        calculator = new CostCalculator();
    }

    public int calculateCost(int parkingDuration){
        return calculator.getCost(parkingDuration);
    }

    public Vehicle getVehicle(){
        return vehicle;
    }
    
	public long getTicketId() {
		return ticketId;
	}
	
	public Slot getSlot() {
		return slot;
	}
}