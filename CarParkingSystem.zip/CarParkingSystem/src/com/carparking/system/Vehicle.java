package com.carparking.system;

public class Vehicle {
    private String numberPlate;
    private String vehicleType = "";
    private int parkingDuration = 0;
	
    public Vehicle(String numberPlate, String vehicleType, int parkingDuration) {
		super();
		this.numberPlate = numberPlate;
		this.vehicleType = vehicleType;
		this.parkingDuration = parkingDuration;
	}

	public String getNumberPlate() {
		return numberPlate;
	}

	public void setNumberPlate(String numberPlate) {
		this.numberPlate = numberPlate;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public int getParkingDuration() {
		return parkingDuration;
	}

	public void setParkingDuration(int parkingDuration) {
		this.parkingDuration = parkingDuration;
	}
}